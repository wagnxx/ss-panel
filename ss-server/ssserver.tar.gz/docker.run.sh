#!/bin/bash

npm i

# 编译
npm run build

# 启动
node ./output/src/app.js