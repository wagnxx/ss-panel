"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("../controllers/index");
require("../controllers/api");
require("../service/ApiService");
require("../controllers/user");
require("../service/UserService");
// import './seq.container' 
