import 'reflect-metadata';
import './ioc';
import { InversifyKoaServer } from 'inversify-koa-utils';
import { Container } from 'inversify';
import { buildProviderModule } from 'inversify-binding-decorators';
import * as bodyParser from 'koa-bodyparser';
import * as serve from 'koa-static';
import * as render from 'koa-swig';
import { wrap } from 'co';

// import * as session from 'koa-generic-session';
// import * as redisStore from 'koa-redis';
const session = require('koa-generic-session');
const redisStore = require('koa-redis');
import './config/mysql';
import { REDIS_CONF } from './config/db';
import { historyApiFallback } from 'koa2-connect-history-api-fallback';
import { VERSION } from './config/project.property';
const container = new Container();
container.load(buildProviderModule());
const server = new InversifyKoaServer(container);

server.setConfig((app) => {
  // api - v1 的proxy

  app.use(bodyParser());

  app.context.render = wrap(
    render({
      root: require('path').join(__dirname, 'views'),
      autoescape: true,
      varControls: ['[[', ']]'],
      // cache: 'memory', // disable, set to false
      cache: false,
      ext: 'html',
      writeBody: false,
    })
  );

  app.use(serve(require('path').join(__dirname, '..', 'dist')));

  // app.use(historyApiFallback({ index: '/ssr', whiteList: [`/${VERSION}`] }));

  app.keys = ['YUGUDS_87831#']; // session密匙
  app.use(
    session({
      // 配置cookie
      cookie: {
        path: '/',
        httpOnly: false,
        // maxAge: 40*1000
        maxAge: 24 * 60 * 60 * 1000,
      },
      // 配置redis
      store: redisStore({
        all: `${REDIS_CONF.host}:${REDIS_CONF.port}`, // 写死本地的redis（暂时）
      }),
    })
  );
});
const app = server.build();

app.listen(3000, () => {
  console.log('server is running over 3000');
});
