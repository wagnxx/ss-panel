// // import * as  sequelizetype from 'sequelize-typescript';

// declare module 'sequelize-typescript';
// declare module '*.css';